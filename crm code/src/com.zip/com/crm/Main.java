package com.crm;

import com.crm.alert.controller.AlertController;
import com.crm.alert.factory.AlertFactory;
import com.crm.alert.factory.LowStockAlertFactory;
import com.crm.alert.model.SystemAlert;
import com.crm.alert.repository.AlertRepository;
import com.crm.common.Employee;
import com.crm.common.Money;
import com.crm.common.enums.ComplaintStatus;
import com.crm.common.enums.PaymentMethodType;

import com.crm.customer.controller.ComplaintController;
import com.crm.customer.model.Complaint;
import com.crm.customer.repository.ComplaintRepository;
import com.crm.payment.model.PaymentTransaction;
import com.crm.persistence.DatabaseConnectionManager;

import static com.crm.common.enums.PaymentMethodType.Card;

public class Main {
    public static void main(String[] args) {
        DatabaseConnectionManager.getInstance().connect();
        System.out.println("CRM System Started...");
        DatabaseConnectionManager.getInstance().disconnect();
        ComplaintRepository complaintRepository = new ComplaintRepository();
        ComplaintController c1 = new ComplaintController(complaintRepository);
        // Money amount = new Money(23.1, "USD");
        // PaymentTransaction p1 = new PaymentTransaction("123", "Ord12", amount, Card);
        // System.out.println(p1.getMethod());
        //
        // --- Demo: Refactored Alert Factory (Factory Method Pattern) ---
        AlertRepository alertRepo = new AlertRepository();

        // Use the Factory Method pattern: Instantiate the specific controller
        AlertController inventoryAlertController = new InventoryAlertController(alertRepo);
        SystemAlert alert = inventoryAlertController.processAlert("ALT-001", "PROD-99");

        System.out.println("Created Alert: " + alert.getClass().getSimpleName() + " for ID: " + alert.getAlertId());

        Employee e = new Employee("ea12", "Ahmed Shafey", "TeamLeader", "exmpl@org.com");
        Complaint c = new Complaint(
                "Ca12", "High");

        c.assignTo(e);
        c.setStatus(ComplaintStatus.Open);
        c.ComplaintDetails();
        c1.createComplaint(c);

    }
}
