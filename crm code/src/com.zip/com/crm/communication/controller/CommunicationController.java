package com.crm.communication.controller;

import com.crm.communication.channel.CommunicationChannel;
import com.crm.communication.factory.CommunicationFactory;

public class CommunicationController {
    public CommunicationChannel selectChannel(CommunicationFactory factory)
    {

        return factory.createChannel();
    }
    public void sendMessage(CommunicationFactory factory, String to, String message) {
        CommunicationChannel channel = selectChannel(factory);
        channel.sendMessage(to, message); // Send the message using the appropriate channel
    }
}
