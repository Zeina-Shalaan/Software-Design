package com.crm.order.repository;

import com.crm.order.model.Product;
import com.crm.persistence.repository.CrudRepository;

import java.util.HashMap;
import java.util.Map;

public class ProductRepository implements CrudRepository<Product> {
    private final Map<String, Product> repository = new HashMap<>();

    @Override
    public void save(String id, Product entity) {
        repository.put(id, entity);
        System.out.println("Product saved in database");
    }

    @Override
    public Product findById(String id) {
        return repository.get(id);
    }

    @Override
    public void update(String id, Product entity) {
        repository.put(id, entity);
        System.out.println("Product updated");
    }

    @Override
    public void delete(String id) {
        repository.remove(id);
        System.out.println("Product removed");
    }
}
