package com.crm.order.controller;

import com.crm.order.model.Order;
import com.crm.order.repository.OrderRepository;

public class OrderController {
    private final OrderRepository orderRepository;

    public OrderController(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public void createOrder(String id,Order order) {
        orderRepository.save(id,order);
    }

    public Order retrieveOrder(String orderId) {
        return orderRepository.findById(orderId);
    }

    public void updateOrder(String id,Order order) {
        orderRepository.update(id,order);
    }

    public void cancelOrder(String orderId) {
        Order o = orderRepository.findById(orderId);
        if (o != null) {
            o.cancel();
            orderRepository.update(orderId,o);
        }
    }
}
